let numtest = 45.32444568;
console.log(numtest);