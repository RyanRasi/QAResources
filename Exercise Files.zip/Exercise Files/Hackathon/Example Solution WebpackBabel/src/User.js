export default class User {
    constructor(title, firstName, lastName, email, phoneNumber, dob, gender) {
        this.title = title;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.dob = dob;
        this.gender = gender;
    }
}