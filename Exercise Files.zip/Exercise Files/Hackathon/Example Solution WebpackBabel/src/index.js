import activateEventListeners from './eventListeners';

activateEventListeners();

