import Form from './Form';

const form = new Form();
form.activateEventListeners();